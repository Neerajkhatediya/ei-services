
EI Services is a simple WordPress plugin for displaying your services.
Plugin allows you to set options(count,orderby,order) according to your need and get custom shortcode based on your settings.
Plugin allows you to customize your frontend view(Set number of services to display,Load More Setting). 

Shortcode
[ei_services count="6" orderby="none" order="DESC"]
